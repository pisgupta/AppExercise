package com.demo.constant;

/**
 * Created by gupta on 6/27/2015.
 */
public class AppConstant {
    /**
     * this class are using for constant value declaration
     * ex :- URL,WebService Path,Web Service Method
     */
    public static final String URL = "https://api.flickr.com/services/feeds/photos_public.gne";
}
