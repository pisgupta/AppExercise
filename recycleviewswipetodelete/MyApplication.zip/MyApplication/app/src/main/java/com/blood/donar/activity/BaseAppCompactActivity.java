package com.blood.donar.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

/**
 * Created by pankaj.kumar on 12/21/2016.
 */

public class BaseAppCompactActivity extends AppCompatActivity {
    private static final String TAG = "BaseAppCompactActivity";
    private ProgressDialog mProgressDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Work under progress");
    }

    public void showProgressBar() {
        if (!mProgressDialog.isShowing()) {
            mProgressDialog.show();
        }
    }

    public void hideProgressBar() {
        mProgressDialog.dismiss();
    }

    public boolean checkNetWorkState() {
        if (isConnected()) {
            return true;
        } else {
            Toast.makeText(this, "No network available", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean isConnected() {
        ConnectivityManager cm = null;
        try {
            cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            return activeNetwork != null
                    && activeNetwork.isConnectedOrConnecting();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
