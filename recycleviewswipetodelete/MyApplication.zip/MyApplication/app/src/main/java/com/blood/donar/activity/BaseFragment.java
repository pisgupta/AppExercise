package com.blood.donar.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

/**
 * Created by gupta on 2/18/2018.
 */

public class BaseFragment extends Fragment {
    private ProgressDialog mProgressDialog;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mProgressDialog = new ProgressDialog(getActivity());
        mProgressDialog.setMessage("Work under progress");
    }


    public void showProgressBar() {
        if (!mProgressDialog.isShowing()) {
            mProgressDialog.show();
        }
    }

    public void hideProgressBar() {
        mProgressDialog.dismiss();
    }

    public boolean checkNetWorkState() {
        if (isConnected()) {
            return true;
        } else {
            Toast.makeText(getActivity(), "No network available", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean isConnected() {
        ConnectivityManager cm = null;
        try {
            cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            return activeNetwork != null
                    && activeNetwork.isConnectedOrConnecting();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
