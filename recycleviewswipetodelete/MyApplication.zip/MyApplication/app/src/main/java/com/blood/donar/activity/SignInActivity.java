package com.blood.donar.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.blood.donar.R;
import com.blood.donar.presenter.SignInPresentor;
import com.blood.donar.presenter.SignInPresentorImpl;
import com.blood.donar.view.SignInView;


public class SignInActivity extends BaseAppCompactActivity implements SignInView, View.OnClickListener {
    private static final String TAG = "SignInActivity";
    private static final int REQUEST_SIGNUP = 0;

    //Widgets declaration
    private EditText inputEmail;
    private EditText inputPassword;
    private AppCompatButton btnLogin;
    private TextView linkSignup;

    //class object declaration
    SignInPresentor mSigniPresentor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in_main);
        findViews();
    }

    /**
     * Find the Views in the layout<br />
     */
    private void findViews() {
        inputEmail = (EditText) findViewById(R.id.input_email);
        inputPassword = (EditText) findViewById(R.id.input_password);
        btnLogin = (AppCompatButton) findViewById(R.id.btn_login);
        linkSignup = (TextView) findViewById(R.id.link_signup);
        inputEmail.setText("pk@gmail.com");
        inputPassword.setText("test123");
        btnLogin.setOnClickListener(this);
        linkSignup.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_login:
                mSigniPresentor = new SignInPresentorImpl(this, this);
                mSigniPresentor.validate(inputEmail, inputPassword);
                break;
            case R.id.link_signup:
                Intent it = new Intent(SignInActivity.this, SignUpActivity.class);
                it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(it);
                break;
        }
    }

    @Override
    public void showError(EditText editText, String message) {
        //display message here accordingly.
        editText.setError(message);
    }

    @Override
    public void showMessage(String message) {
        //display message here accordingly. like error message from server side
        Snackbar.make(getWindow().getDecorView(), message, Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void onSuccess() {
        //Do code for next operation. like go to home activity
        Snackbar.make(getWindow().getDecorView(), "Congratulation", Snackbar.LENGTH_LONG).show();
        Intent intent = new Intent(SignInActivity.this, HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
        finish();
    }

    @Override
    public void showProgress() {
        //To display progress bar
        showProgressBar();
    }

    @Override
    public void hideProgress() {
        //To hide progress bar
        hideProgressBar();
    }

    @Override
    protected void onStop() {
        super.onStop();

    }
}
