package com.blood.donar.activity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatRadioButton;
import android.text.LoginFilter;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.blood.donar.R;
import com.blood.donar.presenter.SignUpPresentor;
import com.blood.donar.presenter.SignUpPresentorImpl;
import com.blood.donar.view.SignUpView;

import java.util.Calendar;

/**
 * Created by gupta on 1/21/2018.
 */


public class SignUpActivity extends BaseAppCompactActivity implements SignUpView, View.OnClickListener {
    private static final String TAG = "SignUpActivity";
    //Widgets declaration
    private EditText inputName;
    private EditText inputEmail;
    private Spinner inputBloodGroup;
    private EditText inputMobile;
    private EditText inputPassword;
    private EditText inputDob;
    private EditText inputLatLng;
    private RadioGroup radiogender;
    private AppCompatRadioButton radioMale;
    private AppCompatRadioButton radioFeMale;
    private AppCompatButton btnSignup;
    private TextView linkLogin;
    private ImageView imgLoction;
    private ImageView imgCalendar;
    //Variable declaration
    private String gender = "";
    private String bloodGrop = "";

    //Class object declaration
    private SignUpPresentorImpl mSignUpPresentor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        findViews();

        mSignUpPresentor = new SignUpPresentorImpl((Activity) this, this);
        MapsActivity.currentLongitude = 0.0;
        MapsActivity.currentLongitude = 0.0;

    }

    /**
     * Find the Views in the layout<br />
     */
    private void findViews() {
        inputName = (EditText) findViewById(R.id.input_name);
        inputEmail = (EditText) findViewById(R.id.input_email);
        inputBloodGroup = (Spinner) findViewById(R.id.input_blood_group);
        inputMobile = (EditText) findViewById(R.id.input_mobile);
        inputPassword = (EditText) findViewById(R.id.input_password);
        inputDob = (EditText) findViewById(R.id.input_dob);
        inputLatLng = (EditText) findViewById(R.id.latlng);
        imgLoction = (ImageView) findViewById(R.id.img_location);
        imgCalendar = (ImageView) findViewById(R.id.imgCalendar);
        radiogender = (RadioGroup) findViewById(R.id.radiogender);
        radioMale = (AppCompatRadioButton) findViewById(R.id.radioMale);
        radioFeMale = (AppCompatRadioButton) findViewById(R.id.radioFeMale);
        btnSignup = (AppCompatButton) findViewById(R.id.btn_signup);
        linkLogin = (TextView) findViewById(R.id.link_login);

        radioMale.setOnClickListener(this);
        radioFeMale.setOnClickListener(this);
        btnSignup.setOnClickListener(this);
        linkLogin.setOnClickListener(this);
        imgLoction.setOnClickListener(this);
        imgCalendar.setOnClickListener(this);

        inputBloodGroup.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                bloodGrop = inputBloodGroup.getSelectedItem().toString().trim();
                Log.d(TAG, "onItemSelected: ");
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        inputLatLng.setText(MapsActivity.currentLatitude + "," + MapsActivity.currentLongitude);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.radioMale:
                gender = "Male";
                break;
            case R.id.radioFeMale:
                gender = "Female";
                break;
            case R.id.btn_signup:
                mSignUpPresentor.validate(inputName, inputEmail, bloodGrop, inputMobile, inputPassword, inputDob, MapsActivity.currentLatitude + "," + MapsActivity.currentLongitude, gender);
                break;
            case R.id.link_login:
                Intent intent = new Intent(SignUpActivity.this, SignInActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                break;
            case R.id.img_location:
                Intent intent1 = new Intent(SignUpActivity.this, MapsActivity.class);
                intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent1);
                break;
            case R.id.imgCalendar:
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);
                new DatePickerDialog(this, onDateSetListener, year, month, day).show();
                break;

        }
    }

    private DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
            Log.d(TAG, "onDateSet: " + i + " " + i1 + " " + i2);
            inputDob.setText(appendZero(i2) + "-" + appendZero(i1) + "-" + i);
        }
    };

    public String appendZero(int i) {
        if (i < 10)
            return "0" + i;
        else
            return i + "";
    }

    @Override
    public void showError(EditText editText, String message) {
        editText.setError(message);
    }

    @Override
    public void showMessage(String message) {
        Snackbar.make(getWindow().getDecorView(), message, Snackbar.LENGTH_LONG).show();

    }

    @Override
    public void onSuccess() {
        Intent intent = new Intent(SignUpActivity.this, SignInActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
        finish();
    }

    @Override
    public void showProgress() {
        showProgressBar();
    }

    @Override
    public void hideProgress() {
        hideProgressBar();
    }
}
