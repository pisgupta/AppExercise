package com.blood.donar.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.blood.donar.R;
import com.blood.donar.model.Camp;


/**
 * Created by pankaj.kumar on 3/6/2017.
 */

public class DonorCampViewAdapter extends RecyclerView.Adapter<DonorCampViewAdapter.CampViewHolder> {
    //String Array
    Camp[] data;
    //class declaration
    Context mContext;

    public DonorCampViewAdapter(Context mContexts, Camp[] data) {
        this.mContext = mContexts;
        this.data = data;
    }

    @Override
    public CampViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.donor_camp_row_view, parent, false);
        return new CampViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CampViewHolder holder, int position) {
        Camp camp = data[position];
        holder.onBind(camp);
    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public static class CampViewHolder extends RecyclerView.ViewHolder {
        //Widget declaration
        private TextView txtCampValue;
        private TextView txtLocationValue;
        private TextView txtOrgByValue;
        private TextView txtCampDateValue;

        public CampViewHolder(View itemView) {
            super(itemView);
            findViews(itemView);
        }

        private void findViews(View view) {
            txtCampValue = (TextView) view.findViewById(R.id.txt_camp_value);
            txtLocationValue = (TextView) view.findViewById(R.id.txt_location_value);
            txtOrgByValue = (TextView) view.findViewById(R.id.txt_org_by_value);
            txtCampDateValue = (TextView) view.findViewById(R.id.txt_camp_date_value);
        }

        public void onBind(Camp camp) {
            txtCampDateValue.setText(camp.getCamp_title());
            txtLocationValue.setText(camp.getLocation());
            txtOrgByValue.setText(camp.getOrg_by());
            txtCampDateValue.setText(camp.getCamp_date());
        }
    }

}
