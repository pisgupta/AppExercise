package com.blood.donar.api;


import com.blood.donar.model.DonorCampResponse;
import com.blood.donar.model.DonorProfileResponse;
import com.blood.donar.model.SignInParam;
import com.blood.donar.model.SignInResponse;
import com.blood.donar.model.SignUpResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

/**
 * Created by pankaj.kumar on 12/23/2016.
 */

public interface RestApi {
    //public static final String DEV_URL = "http://xyz.netsmartz.us";

    //public static final String DEV_URL = "http://trackdrivers.netsmartz.us";

    public static final String DEV_URL = "http://bloodngo.com/ngo_api/";

    //    REQUEST METHOD

    //  Every method must have an HTTP annotation that provides the request method and relative URL.
    // There are five built-in annotations:
    // GET, POST, PUT, DELETE, and HEAD.
    // The relative URL of the resource is specified in the annotation.
    //An object can be specified for use as an HTTP request body with the @Body annotation.
    // @Headers("Content-Type:application/x-www-form-urlencoded")
    @FormUrlEncoded
    @POST("v1/register")
    Call<SignUpResponse> register(@Field("name") String name, @Field("email") String email, @Field("blood_group") String blood_group, @Field("mobile") String mobile, @Field("password") String password, @Field("dob") String dob, @Field("latitude") String latitude, @Field("longitude") String longitude, @Field("gender") String gender);
    // Call<SignUpResponse> register(@Body SignUpParam body);

    @FormUrlEncoded
    @POST("v1/login")
    Call<SignInResponse> signIn(@Field("email") String email, @Field("password") String password);


   // @FormUrlEncoded
    @POST("v1/camp")
    Call<DonorCampResponse> camp();


    @FormUrlEncoded
    @POST("v1/getProfile")
    Call<DonorProfileResponse> getProfile(@Field("api_key") String api_key);


    @FormUrlEncoded
    @POST("v1/update")
    Call<SignInResponse> update(@Field("email") String email, @Field("password") String password);


    @FormUrlEncoded
    @POST("v1/donation")
    Call<SignInResponse> donation(@Field("email") String email, @Field("password") String password);






    @POST("/test")
    Call<SignInResponse> test(@Body SignInParam body);
}
