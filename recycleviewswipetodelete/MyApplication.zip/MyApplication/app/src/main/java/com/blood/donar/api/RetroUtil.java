package com.blood.donar.api;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by pankaj.kumar on 12/23/2016.
 */

public class RetroUtil {

    private static Retrofit getHost(String url) {
        return new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .client(createLog())
                .build();
    }

    public static RestApi getApiCall(String url) {
        return getHost(url).create(RestApi.class);
    }
    private static OkHttpClient createLog() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(interceptor)
                //.addInterceptor(REWRITE_CACHE_CONTROL_INTERCEPTOR)
                .addNetworkInterceptor(new Interceptor() {
                    @Override
                    public okhttp3.Response intercept(Chain chain) throws IOException {
                        //Request.Builder requestBuilder = chain.request().newBuilder();
                        //requestBuilder.header("Content-Type", "application/json");

                        Request request = chain.request().newBuilder()
                                 //.addHeader("Content-Type", "application/x-www-form-urlencoded")
                                .build();
                        return chain.proceed(request);
                    }
                }).build();
        return client;
    }
}
