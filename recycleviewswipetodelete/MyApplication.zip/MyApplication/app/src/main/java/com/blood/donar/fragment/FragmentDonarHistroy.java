package com.blood.donar.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.blood.donar.R;
import com.blood.donar.model.DonorCampResponse;
import com.blood.donar.view.DonarCampView;

public class FragmentDonarHistroy extends Fragment implements DonarCampView{

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_donar_histroy, container, false);
    }

    @Override
    public void showMessage(String message) {

    }

    @Override
    public void onSuccess(DonorCampResponse donarCampModel) {

    }

    @Override
    public void showProgress() {

    }

    @Override
    public void hideProgress() {

    }
}
