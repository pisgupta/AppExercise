package com.blood.donar.fragment;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.blood.donar.R;
import com.blood.donar.activity.BaseFragment;
import com.blood.donar.model.DonorProfileResponse;
import com.blood.donar.presenter.DonorProfilePresenterImpl;
import com.blood.donar.presenter.DonorProfilePresentor;
import com.blood.donar.view.ProfileView;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentProfile extends BaseFragment implements ProfileView {
    private DonorProfilePresentor donorProfilePresentor;

    public FragmentProfile() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        donorProfilePresentor = new DonorProfilePresenterImpl((AppCompatActivity) getActivity(), this);
        if (checkNetWorkState()){
            donorProfilePresentor.getDonorProfile();
        }
        return view;
    }

    @Override
    public void showMessage(String message) {

    }

    @Override
    public void onSuccess(DonorProfileResponse donarProfile) {

    }

    @Override
    public void showProgress() {

    }

    @Override
    public void hideProgress() {

    }
}
