package com.blood.donar.interacor;

import android.support.v7.app.AppCompatActivity;

import com.blood.donar.model.DonorCampResponse;
import com.blood.donar.presenter.DonorCampPresenter;

/**
 * Created by gupta on 2/18/2018.
 */

public interface DonorCampInteractor {
    public void getCamp(AppCompatActivity activity, DonorCampResponse donorCampModel, DonorCampPresenter.OnDonorCampCompleteListener onDonorCampCompleteListener);
}
