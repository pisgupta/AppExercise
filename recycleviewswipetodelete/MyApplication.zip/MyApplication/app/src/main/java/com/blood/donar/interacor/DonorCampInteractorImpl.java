package com.blood.donar.interacor;

import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.blood.donar.api.RestApi;
import com.blood.donar.api.RetroUtil;
import com.blood.donar.model.DonorCampResponse;
import com.blood.donar.presenter.DonorCampPresenter;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by gupta on 2/18/2018.
 */

public class DonorCampInteractorImpl implements DonorCampInteractor {
    private static final String TAG = "DonorCampInteractorImpl";

    @Override
    public void getCamp(AppCompatActivity activity, DonorCampResponse donorCampModel, final DonorCampPresenter.OnDonorCampCompleteListener onDonorCampCompleteListener) {

        RetroUtil.getApiCall(RestApi.DEV_URL).camp().enqueue(new Callback<DonorCampResponse>() {
            @Override
            public void onResponse(Call<DonorCampResponse> call, Response<DonorCampResponse> response) {
                Log.d(TAG, "onResponse: ");
                if (response.code() == 200) {
                    onDonorCampCompleteListener.onSuccess(response.body());
                } else {
                    onDonorCampCompleteListener.onFail(response.message());
                }

            }

            @Override
            public void onFailure(Call<DonorCampResponse> call, Throwable t) {
                Log.d(TAG, "onFailure: ");
                onDonorCampCompleteListener.onFail(t.getMessage());
            }
        });
    }
}

