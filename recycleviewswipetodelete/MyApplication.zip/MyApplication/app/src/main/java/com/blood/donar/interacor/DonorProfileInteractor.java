package com.blood.donar.interacor;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;

import com.blood.donar.model.ProfileModel;
import com.blood.donar.presenter.DonorProfilePresentor;

/**
 * Created by gupta on 2/18/2018.
 */

public interface DonorProfileInteractor {
    public void getProfile(AppCompatActivity activity, ProfileModel profileModel, DonorProfilePresentor.onDonorProfileCompleteListener onDonorProfileCompleteListener);

}
