package com.blood.donar.interacor;

import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.blood.donar.R;
import com.blood.donar.activity.HomeActivity;
import com.blood.donar.api.RestApi;
import com.blood.donar.api.RetroUtil;
import com.blood.donar.model.DonorProfileResponse;
import com.blood.donar.model.ProfileModel;
import com.blood.donar.preference.PreferencesKey;
import com.blood.donar.presenter.DonorProfilePresentor;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by gupta on 2/18/2018.
 */

public class DonorProfileInteractorImpl implements DonorProfileInteractor {
    private static final String TAG = "DonorProfileInteractorI";

    @Override
    public void getProfile(AppCompatActivity activity, ProfileModel profileModel, DonorProfilePresentor.onDonorProfileCompleteListener onDonorProfileCompleteListener) {
        //RetroUtil.getApiCall(RestApi.DEV_URL).signIn(signInParam.getEmail(), signInParam.getPassword()).enqueue(new Callback<SignInResponse>() {
        RetroUtil.getApiCall(RestApi.DEV_URL).getProfile(HomeActivity.preference.getString(PreferencesKey.KEY_API_KEY)).enqueue(new Callback<DonorProfileResponse>() {
            @Override
            public void onResponse(Call<DonorProfileResponse> call, Response<DonorProfileResponse> response) {
                Log.d(TAG, "onResponse: ");
            }

            @Override
            public void onFailure(Call<DonorProfileResponse> call, Throwable t) {
                Log.d(TAG, "onFailure: ");
            }
        });
    }
}
