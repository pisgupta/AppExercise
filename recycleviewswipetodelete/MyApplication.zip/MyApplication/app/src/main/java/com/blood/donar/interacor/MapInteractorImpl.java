package com.blood.donar.interacor;

import android.content.Context;

import com.blood.donar.presenter.MapPresenter;

/**
 * Created by gupta on 12/30/2017.
 */

public class MapInteractorImpl implements MapInteractor {
    @Override
    public void getLocationData(Context context, String parameter, MapPresenter.onMapCompleteListener onMapCompleteListener) {

    }
}
