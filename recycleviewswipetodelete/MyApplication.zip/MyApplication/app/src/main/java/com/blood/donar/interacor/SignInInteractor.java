package com.blood.donar.interacor;

import android.support.v7.app.AppCompatActivity;

import com.blood.donar.model.SignInParam;
import com.blood.donar.presenter.SignInPresentor;

/**
 * Created by pankaj.kumar on 10/19/2016.
 */

public interface SignInInteractor {
    public void signIn(AppCompatActivity activity, SignInParam signupParam, SignInPresentor.onSignInCompleteListener onSignInCompleteListener);
}
