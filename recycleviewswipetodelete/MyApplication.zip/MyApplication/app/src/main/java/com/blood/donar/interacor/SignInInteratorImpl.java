package com.blood.donar.interacor;

import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.blood.donar.api.RestApi;
import com.blood.donar.api.RetroUtil;
import com.blood.donar.model.SignInParam;
import com.blood.donar.model.SignInResponse;
import com.blood.donar.preference.Preferences;
import com.blood.donar.presenter.SignInPresentor;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by pankaj.kumar on 10/19/2016.
 */

public class SignInInteratorImpl implements SignInInteractor {
    private static final String TAG = "SignInInteratorImpl";


    @Override
    public void signIn(AppCompatActivity activity, SignInParam signInParam, final SignInPresentor.onSignInCompleteListener onSignInCompleteListener) {
        RetroUtil.getApiCall(RestApi.DEV_URL).signIn(signInParam.getEmail(), signInParam.getPassword()).enqueue(new Callback<SignInResponse>() {
            @Override
            public void onResponse(Call<SignInResponse> call, final Response<SignInResponse> response) {
                Log.d(TAG, "onResponse: ");
                int code = response.code();
                if (code == 200) {
                    Log.d(TAG, "onResponse: " + response.message());
                    Log.d(TAG, "onResponse: " + response.body());
                    SignInResponse signInResponse = response.body();
                    onSignInCompleteListener.onSuccess(signInResponse);
                }
            }

            @Override
            public void onFailure(Call<SignInResponse> call, Throwable t) {
                onSignInCompleteListener.onFail(t.getMessage());
            }
        });
    }


}
