package com.blood.donar.interacor;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;

import com.blood.donar.model.SignUpParam;
import com.blood.donar.presenter.SignUpPresentor;


/**
 * Created by pankaj.kumar on 10/19/2016.
 */

public interface SignUpInteractor {
    public void signUp(Activity activity, SignUpParam signupParam, SignUpPresentor.onSignupCompleteListener onSignupCompleteListener);
}
