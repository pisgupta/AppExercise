package com.blood.donar.interacor;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.blood.donar.api.RestApi;
import com.blood.donar.api.RetroUtil;
import com.blood.donar.model.SignInResponse;
import com.blood.donar.model.SignUpParam;
import com.blood.donar.model.SignUpResponse;
import com.blood.donar.presenter.SignUpPresentor;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by pankaj.kumar on 10/19/2016.
 */

public class SignUpInteratorImpl implements SignUpInteractor {
    private static final String TAG = "SignUpInteratorImpl";


    @Override
    public void signUp(final Activity activity, SignUpParam signupParam, final SignUpPresentor.onSignupCompleteListener onSignupCompleteListener) {
        RetroUtil.getApiCall(RestApi.DEV_URL).register(signupParam.getName(), signupParam.getEmail(), signupParam.getBlood_group(), signupParam.getMobile(), signupParam.getPassword(), signupParam.getDob(), signupParam.getLatitude(), signupParam.getLongitude(), signupParam.getGender()).enqueue(new Callback<SignUpResponse>() {
            @Override
            public void onResponse(Call<SignUpResponse> call, Response<SignUpResponse> response) {
                Log.d(TAG, "onResponse: ");
                int statusCode = response.code();
                if (response != null) {
                    onSignupCompleteListener.onSuccess(response.body());
                } else {
                    onSignupCompleteListener.onFail("Response not come from server");
                }
            }

            @Override
            public void onFailure(Call<SignUpResponse> call, Throwable t) {
                Log.d(TAG, "onFailure: ");
                onSignupCompleteListener.onFail(t.getMessage());
            }
        });
    }
}
