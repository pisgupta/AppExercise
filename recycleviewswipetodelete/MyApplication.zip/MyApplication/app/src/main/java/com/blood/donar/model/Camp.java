package com.blood.donar.model;

/**
 * Created by gupta on 2/18/2018.
 */

public class Camp {
    private String location;

    private String camp_date;

    private String camp_title;

    private String org_by;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCamp_date() {
        return camp_date;
    }

    public void setCamp_date(String camp_date) {
        this.camp_date = camp_date;
    }

    public String getCamp_title() {
        return camp_title;
    }

    public void setCamp_title(String camp_title) {
        this.camp_title = camp_title;
    }

    public String getOrg_by() {
        return org_by;
    }

    public void setOrg_by(String org_by) {
        this.org_by = org_by;
    }
}
