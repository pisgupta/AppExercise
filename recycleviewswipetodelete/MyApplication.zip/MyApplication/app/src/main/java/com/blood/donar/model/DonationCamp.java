package com.blood.donar.model;

/**
 * Created by gupta on 2/18/2018.
 */

public class DonationCamp {
}
