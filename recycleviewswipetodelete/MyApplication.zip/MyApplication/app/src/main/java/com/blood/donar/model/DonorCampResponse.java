package com.blood.donar.model;

/**
 * Created by gupta on 2/18/2018.
 */

public class DonorCampResponse {
    private Camp[] camp;

    private boolean error;

    public Camp[] getCamp() {
        return camp;
    }

    public void setCamp(Camp[] camp) {
        this.camp = camp;
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }
}
