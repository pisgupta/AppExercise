package com.blood.donar.model;

/**
 * Created by gupta on 2/18/2018.
 */

public class DonorProfileResponse {
    private boolean error;
    private ProfileModel[] profile;

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public ProfileModel[] getProfile() {
        return profile;
    }

    public void setProfile(ProfileModel[] profile) {
        this.profile = profile;
    }
}
