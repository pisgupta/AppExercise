package com.blood.donar.model;

/**
 * Created by gupta on 12/30/2017.
 */

public class HttpModel {
    private String url;
    private boolean ispost;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean ispost() {
        return ispost;
    }

    public void setIspost(boolean ispost) {
        this.ispost = ispost;
    }
}
