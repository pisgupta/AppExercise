package com.blood.donar.preference;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by prerna.kapoor on 1/15/2016.
 */
public class Preferences {
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private static Preferences preferences;

    private Preferences(Context context) {
        sharedPreferences = context.getSharedPreferences("bloodDonar", Context.MODE_APPEND);
        editor = sharedPreferences.edit();
    }

    public static Preferences getInstance(Context context) {
        if (preferences == null)
            preferences = new Preferences(context);
        return preferences;
    }

    public void putString(String key, String value) {
        editor.putString(key, value);
        editor.commit();
    }

    public String getString(String key) {
       return sharedPreferences.getString(key, "");
    }
}
