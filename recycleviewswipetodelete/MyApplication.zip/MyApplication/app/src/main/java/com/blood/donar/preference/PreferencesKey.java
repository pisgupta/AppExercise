package com.blood.donar.preference;

/**
 * Created by gupta on 2/5/2018.
 */

public class PreferencesKey {
    public static String KEY_USER_NAME = "user_name";
    public static String KEY_EMAIL = "email";
    public static String KEY_API_KEY = "api_key";
}
