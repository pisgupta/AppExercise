package com.blood.donar.presenter;

import com.blood.donar.model.DonorCampResponse;

/**
 * Created by gupta on 2/18/2018.
 */

public interface DonorCampPresenter {
    public interface OnDonorCampCompleteListener {
        public void onSuccess(DonorCampResponse response);

        public void onFail(String message);
    }

    public void getDonorCamp();

}
