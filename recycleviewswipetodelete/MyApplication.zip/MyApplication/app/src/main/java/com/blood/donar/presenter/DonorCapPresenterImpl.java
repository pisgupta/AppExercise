package com.blood.donar.presenter;

import android.support.v7.app.AppCompatActivity;

import com.blood.donar.interacor.DonorCampInteractor;
import com.blood.donar.interacor.DonorCampInteractorImpl;
import com.blood.donar.model.DonorCampResponse;
import com.blood.donar.view.DonarCampView;

/**
 * Created by gupta on 2/18/2018.
 */

public class DonorCapPresenterImpl implements DonorCampPresenter, DonorCampPresenter.OnDonorCampCompleteListener {
    private AppCompatActivity appCompatActivity;
    private DonarCampView donarCampView;
    private DonorCampInteractor donorCampInteractor;

    public DonorCapPresenterImpl(AppCompatActivity appCompatActivity, DonarCampView donarCampView) {
        this.appCompatActivity = appCompatActivity;
        this.donarCampView = donarCampView;
        donorCampInteractor = new DonorCampInteractorImpl();
    }

    @Override
    public void getDonorCamp() {
        donarCampView.showProgress();
        DonorCampResponse donorCampModel = new DonorCampResponse();
        donorCampInteractor.getCamp(appCompatActivity, donorCampModel, this);
    }

    @Override
    public void onSuccess(DonorCampResponse response) {
        donarCampView.hideProgress();
        donarCampView.onSuccess(response);
    }

    @Override
    public void onFail(String message) {
        donarCampView.hideProgress();
        donarCampView.showMessage(message);
    }
}
