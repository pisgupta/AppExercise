package com.blood.donar.presenter;

import android.support.v7.app.AppCompatActivity;

import com.blood.donar.interacor.DonorProfileInteractor;
import com.blood.donar.interacor.DonorProfileInteractorImpl;
import com.blood.donar.model.DonorProfileResponse;
import com.blood.donar.model.ProfileModel;
import com.blood.donar.view.ProfileView;

/**
 * Created by gupta on 2/18/2018.
 */

public class DonorProfilePresenterImpl implements DonorProfilePresentor, DonorProfilePresentor.onDonorProfileCompleteListener {
    private AppCompatActivity appCompatActivity;
    private ProfileView profileView;
    private DonorProfileInteractor donorProfileInteractor;

    public DonorProfilePresenterImpl(AppCompatActivity appCompatActivity, ProfileView profileView) {
        this.appCompatActivity = appCompatActivity;
        this.profileView = profileView;
        donorProfileInteractor = new DonorProfileInteractorImpl();
    }

    @Override
    public void getDonorProfile() {
        profileView.showProgress();
        ProfileModel profileModel = new ProfileModel();
        donorProfileInteractor.getProfile(appCompatActivity, profileModel, this);
    }

    @Override
    public void onSuccess(DonorProfileResponse response) {
        profileView.hideProgress();
        profileView.onSuccess(response);
    }

    @Override
    public void onFail(String message) {
        profileView.hideProgress();
        profileView.showMessage(message);
    }
}
