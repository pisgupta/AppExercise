package com.blood.donar.presenter;

import com.blood.donar.model.DonorProfileResponse;

/**
 * Created by gupta on 2/18/2018.
 */

public interface DonorProfilePresentor {
    public interface onDonorProfileCompleteListener {
        public void onSuccess(DonorProfileResponse response);

        public void onFail(String message);
    }

    public void getDonorProfile();

}
