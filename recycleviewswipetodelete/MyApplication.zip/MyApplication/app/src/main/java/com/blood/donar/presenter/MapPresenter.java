package com.blood.donar.presenter;

/**
 * Created by gupta on 12/30/2017.
 */

public interface MapPresenter {
    public interface onMapCompleteListener {
        public void onSuccess(String msg, int requestCode, int responseCode);

        public void onFail(String message);

    }

    public void getMarkerData();

    public void putMapData(String locationId);
}
