package com.blood.donar.presenter;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;

import com.blood.donar.interacor.MapInteractor;
import com.blood.donar.interacor.MapInteractorImpl;
import com.blood.donar.model.HttpModel;
import com.blood.donar.view.MapView;


/**
 * Created by gupta on 12/30/2017.
 */

public class MapPresentorImp implements MapPresenter, MapPresenter.onMapCompleteListener {
    private MapInteractor mapInteractor;
    private MapView mapView;
    private Context context;


    public MapPresentorImp(AppCompatActivity context, MapView mapView) {
        this.context = context;
        this.mapView = mapView;
        mapInteractor = new MapInteractorImpl();

    }

    @Override
    public void getMarkerData() {
        HttpModel httpModel = new HttpModel();
        mapView.showProgress();
        mapInteractor.getLocationData(context, httpModel.getUrl(), this);
    }

    @Override
    public void putMapData(String locationId) {

    }

    @Override
    public void onSuccess(String responseData, int requestCode, int responseCode) {
        mapView.hideProgress();
        mapView.getResponse(responseData, requestCode);
    }

    @Override
    public void onFail(String message) {
        mapView.hideProgress();
    }
}
