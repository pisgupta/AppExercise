package com.blood.donar.presenter;

import android.widget.EditText;

import com.blood.donar.model.SignInResponse;

/**
 * Created by pankaj.kumar on 10/19/2016.
 */

public interface SignInPresentor {
    public interface onSignInCompleteListener {
        public void onSuccess(SignInResponse signInResponse);
        public void onFail(String message);
    }

    public void validate(EditText edtUserName, EditText edtUserPassword);

}
