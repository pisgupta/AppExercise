package com.blood.donar.presenter;

import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;

import com.blood.donar.interacor.SignInInteractor;
import com.blood.donar.interacor.SignInInteratorImpl;
import com.blood.donar.model.SignInParam;
import com.blood.donar.model.SignInResponse;
import com.blood.donar.preference.Preferences;
import com.blood.donar.preference.PreferencesKey;
import com.blood.donar.view.SignInView;


/**
 * Created by pankaj.kumar on 10/19/2016.
 */

public class SignInPresentorImpl implements SignInPresentor, SignInPresentor.onSignInCompleteListener {
    private static final String TAG = "SignInPresentorImpl";
    private AppCompatActivity mAppCompatActivity;
    private SignInView signInView;
    private SignInInteractor signInInteractor;
    public static Preferences preferences;

    public SignInPresentorImpl(AppCompatActivity compatActivity, SignInView signInView) {
        this.mAppCompatActivity = compatActivity;
        this.signInView = signInView;
        this.signInInteractor = new SignInInteratorImpl();
        preferences = Preferences.getInstance(compatActivity);
    }


    @Override
    public void onSuccess(SignInResponse signInResponse) {
        Log.d(TAG, "onSuccess: ");
        signInView.hideProgress();
        if (signInResponse != null) {
            if (!signInResponse.isError()) {
                preferences.putString(PreferencesKey.KEY_USER_NAME, signInResponse.getName());
                preferences.putString(PreferencesKey.KEY_EMAIL, signInResponse.getEmail());
                preferences.putString(PreferencesKey.KEY_API_KEY, signInResponse.getApiKey());
                signInView.onSuccess();
            } else {
                signInView.showMessage(signInResponse.getMessage());
            }
        } 
    }

    @Override
    public void onFail(String error) {
        signInView.hideProgress();
        signInView.showMessage(error);
    }

    @Override
    public void validate(EditText edtUserName, EditText edtUserPassword) {
        if (TextUtils.isEmpty(edtUserName.getText().toString().trim())) {
            signInView.showError(edtUserName, "Please enter user name.");
            return;
        }
        if (TextUtils.isEmpty(edtUserPassword.getText().toString().trim())) {
            signInView.showError(edtUserPassword, "Please enter user Password.");
            return;
        }
        signInView.showProgress();
        SignInParam mSignInParam = new SignInParam();
        mSignInParam.setUsername(edtUserName.getText().toString().trim());
        mSignInParam.setEmail(edtUserName.getText().toString().trim());
        mSignInParam.setPassword(edtUserPassword.getText().toString().trim());
        signInInteractor.signIn(mAppCompatActivity, mSignInParam, this);
    }
}
