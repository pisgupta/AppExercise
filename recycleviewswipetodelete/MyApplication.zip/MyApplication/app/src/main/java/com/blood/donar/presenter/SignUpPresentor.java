package com.blood.donar.presenter;

import android.widget.EditText;

import com.blood.donar.model.SignUpResponse;

/**
 * Created by pankaj.kumar on 10/19/2016.
 */

public interface SignUpPresentor {
    public interface onSignupCompleteListener {
        public void onSuccess(SignUpResponse response);
        public void onFail(String message);
    }

    public void validate(EditText edtName, EditText edtEmail, String bloodGr, EditText edtMob, EditText edtPass, EditText edtDOB,String location,String gender);

}
