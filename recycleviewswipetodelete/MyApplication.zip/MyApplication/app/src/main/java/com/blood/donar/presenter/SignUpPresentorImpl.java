package com.blood.donar.presenter;

import android.app.Activity;
import android.support.design.widget.Snackbar;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;

import com.blood.donar.interacor.SignUpInteractor;
import com.blood.donar.interacor.SignUpInteratorImpl;
import com.blood.donar.model.SignUpParam;
import com.blood.donar.model.SignUpResponse;
import com.blood.donar.util.UtilityClass;
import com.blood.donar.view.SignUpView;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;


/**
 * Created by pankaj.kumar on 10/19/2016.
 */

public class SignUpPresentorImpl implements SignUpPresentor, SignUpPresentor.onSignupCompleteListener {
    private static final String TAG = "SignInPresentorImpl";
    private Activity appCompatActivity;
    private SignUpView signupView;
    private SignUpInteractor signupInteractor;
    private String lat, lng;

    public SignUpPresentorImpl(Activity appCompatActivity, SignUpView signupView) {
        this.appCompatActivity = appCompatActivity;
        this.signupView = signupView;
        this.signupInteractor = new SignUpInteratorImpl();
    }

    @Override
    public void validate(EditText edtName, EditText edtEmail, String bloodGr, EditText edtMob, EditText edtPass, EditText edtDOB, String location, String gender) {
        //Do validation here
        if (TextUtils.isEmpty(edtName.getText().toString().trim())) {
            signupView.showError(edtName, "Please enter first name.");
            return;
        }
        if (TextUtils.isEmpty(edtEmail.getText().toString().trim())) {
            signupView.showError(edtEmail, "Please enter email address");
            return;
        }
        if (!UtilityClass.isValidEmailAddress(edtEmail.getText().toString().trim())) {
            signupView.showError(edtEmail, "Please enter valid email address.");
            return;
        }
        if (TextUtils.isEmpty(edtMob.getText().toString().trim())) {
            signupView.showError(edtMob, "Please enter mobile number.");
            return;
        }
        if (TextUtils.isEmpty(edtPass.getText().toString().trim())) {
            signupView.showError(edtPass, "Please enter Password.");
            return;
        }
        if (TextUtils.isEmpty(edtDOB.getText().toString().trim())) {
            signupView.showError(edtDOB, "Please enter date of birth");
            return;
        }
        if (location.equals("0.0,0.0")) {
            Snackbar.make(((Activity) appCompatActivity).getWindow().getDecorView(), "Location is not set please select location from location button", Snackbar.LENGTH_LONG).show();
            return;
        } else {
            String[] loc = location.split(",");
            lat = loc[0];
            lng = loc[1];
        }
        if (gender.equals("")) {
            Snackbar.make(((Activity) appCompatActivity).getWindow().getDecorView(), "Please select gender", Snackbar.LENGTH_LONG).show();
            return;
        }
        SignUpParam signupParam = new SignUpParam();
        signupParam.setName(edtName.getText().toString().trim());
        signupParam.setEmail(edtEmail.getText().toString().trim());
        signupParam.setBlood_group(bloodGr);
        signupParam.setMobile(edtMob.getText().toString().trim());
        signupParam.setPassword(edtPass.getText().toString().trim());
        signupParam.setDob(edtDOB.getText().toString().trim());
        signupParam.setLatitude(lat);
        signupParam.setLongitude(lng);
        signupParam.setGender(gender);
        //Snackbar.make(((Activity) appCompatActivity).getWindow().getDecorView(), "Congratulation", Snackbar.LENGTH_LONG).show();
        //Calling api using interactor
        signupView.showProgress();
        signupInteractor.signUp(appCompatActivity, signupParam, this);

    }

    @Override
    public void onSuccess(SignUpResponse response) {
        Log.e(TAG, "onSuccess: " + response);
        signupView.hideProgress();
        try {
            if (!response.isError()) {
                signupView.onSuccess();
            } else {
                signupView.showMessage(response.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onFail(String error) {
        signupView.hideProgress();
        signupView.showMessage(error);
    }
}
