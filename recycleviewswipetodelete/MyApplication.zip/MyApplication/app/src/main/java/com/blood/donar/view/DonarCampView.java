package com.blood.donar.view;

import com.blood.donar.model.DonorCampResponse;

/**
 * Created by gupta on 2/18/2018.
 */

public interface DonarCampView {

    public void showMessage(String message);

    public void onSuccess(DonorCampResponse donarCampModel);

    public void showProgress();

    public void hideProgress();
}
