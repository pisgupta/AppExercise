package com.blood.donar.view;

/**
 * Created by gupta on 12/30/2017.
 */

public interface MapView {

    public void showProgress();
    public void hideProgress();
    public void getResponse(String s, int requestCode);
}
