package com.blood.donar.view;

import com.blood.donar.model.DonorProfileResponse;

/**
 * Created by gupta on 2/18/2018.
 */

public interface ProfileView {

    public void showMessage(String message);

    public void onSuccess(DonorProfileResponse donarProfile);

    public void showProgress();

    public void hideProgress();
}
