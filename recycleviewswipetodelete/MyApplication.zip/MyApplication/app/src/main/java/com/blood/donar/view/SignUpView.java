package com.blood.donar.view;

import android.widget.EditText;

/**
 * Created by pankaj.kumar on 10/19/2016.
 */

public interface SignUpView {
    public void showError(EditText editText, String message);

    public void showMessage(String message);

    public void onSuccess();

    public void showProgress();

    public void hideProgress();
}
